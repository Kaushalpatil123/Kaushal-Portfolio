import "./App.css";
import SearchBar from "./Components/SearchBar";

function App() {
  return (
    <>
      <SearchBar />
    </>
  );
}

export default App;
